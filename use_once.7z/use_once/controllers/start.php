<?php
namespace controllers;
require_once ('..\models\create_db.php');
require_once ('..\models\create_tables.php');
use function models\create_main_db;
use function models\create_table_admins;
use function models\create_table_tasks;



create_main_db();
create_table_admins();
create_table_tasks();