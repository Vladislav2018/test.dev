<?php
$dsn = "mysql:host=localhost;dbname=testdb;";
$db = new PDO($dsn,'root','root');
$data = [
    ['amd1', 'adm2', 'adm3', 'adm4'],
    ['amd@mail.com', 'ard@dfg.ty', 'qwerty@was.tr', 'zasd@sdfg.ry'],
    [
        md5('1234'),
        md5('abcd'),
        md5('qwerty'),
        md5('abcd')
        ]
];
$req = 'INSERT INTO `admins` (`nikname`, `email`, `password`) VALUES (?, ?, ?)';

for ($i = 0; $i < 4; $i++)
{
    $stmp = $db->prepare($req);
    $stmp->execute(array($data[0][$i],$data[1][$i],$data[2][$i]));
}
