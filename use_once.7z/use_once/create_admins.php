<?php
$dsn = "mysql:host=localhost;dbname=testdb;";
$db = new PDO($dsn,'root','root');
$data = [
    ['amd1', 'adm2', 'adm3', 'adm4'],
    ['amd@mail.com', 'ard@dfg.ty', 'qwerty@was.tr', 'zasd@sdfg.ry'],
    [
        password_hash('1234', PASSWORD_DEFAULT),
        password_hash('abcd', PASSWORD_DEFAULT),
        password_hash('qwerty', PASSWORD_DEFAULT),
        password_hash('abcd', PASSWORD_DEFAULT)
        ]
];
$req = 'INSERT INTO `admins` (`nikname`, `email`, `password`) VALUES (?, ?, ?)';

for ($i = 0; $i < 4; $i++)
{
    $stmp = $db->prepare($req);
    $stmp->execute(array($data[0][$i],$data[1][$i],$data[2][$i]));
}
