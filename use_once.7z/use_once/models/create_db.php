<?php
namespace models;
require_once "DBConnection.php";

function create_main_db()
{
    $query = "CREATE DATABASE IF NOT EXISTS testDB";
    $db_connection = DBConnection::getInstance();
    $db_connection->execute($query);
}