<?php
namespace models;
require_once "DBConnection.php";

function create_table_admins()
{
    $db_conn = DBConnection::getInstance();
    $query = "CREATE TABLE IF NOT EXISTS admins(
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                nikname VARCHAR(25) NOT NULL,
                email VARCHAR(200) NOT NULL,
                password TEXT NOT NULL)";
    $db_conn->execute($query);
}
function create_table_tasks()
{
    $db_conn = DBConnection::getInstance();
    $query = "CREATE TABLE IF NOT EXISTS tasks(
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                nikname VARCHAR(25) NOT NULL,
                email VARCHAR(200) NOT NULL,
                task TEXT NOT NULL)";
    $db_conn->execute($query);
}